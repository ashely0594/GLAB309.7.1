package com.perscholas.SpringMySqlApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMySqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
